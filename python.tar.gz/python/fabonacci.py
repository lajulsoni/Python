
n = int(input("enter the range :" ))
print ("range :",n)
a=0
b=1
c=0
for i in range(n):
	print (a)
	c = a+b
	a =b
	b=c
	n=n-1



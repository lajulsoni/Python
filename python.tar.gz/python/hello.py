#comment 1st line
print"welcome to python"
#second comment

ch = "lajul"
print ch[0]
print ch[0:]
print ch[2:4]
print ch * 2
print ch+"soni"
print ch[-2]

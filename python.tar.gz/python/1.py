a=b=c=5
print a, b, c

d,e,f = 10,12.0,"lajul"
print d,e,f

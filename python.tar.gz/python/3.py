#      list

list0 = [1,"lajul",18.9]
list1 = ["lajul","soni"] 

print list0
print list0 + list1
#list1[2]= "lucky"
print list1 

#     Tupple
t = (1,2,3,4,5,6,"lajul")
t1 = ("abcd","def")
print t[0]
print t
print t + t1
print list1
#      Dictonary

d = {"lajul":"soni",'lucky':'Soni'}
print d
print["lajul"]
print['soni'] 
d["lajul"]="lovely"
print d.keys()
print d.values()
